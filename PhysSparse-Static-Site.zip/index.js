"use strict";

const reduction = window.matchMedia("(prefers-reduced-motion: reduce)");

function autoPlay(video) {
  if (!reduction.matches) {
    video.play().catch(() => {});
  }
}

const observer = new IntersectionObserver((entries) => {
  for (const entry of entries) {
    const video = entry.target;
    if (entry.isIntersecting) {
      autoPlay(video);
    } else {
      video.pause();
    }
  }
}, { threshold: 0.38 });

for (const panel of document.querySelectorAll("[data-interactive]")) {
  const buttons = Array.from(panel.querySelectorAll("[data-choice]"));
  const entries = JSON.parse(panel.querySelector("[data-choices]").textContent);
  const preview = panel.querySelector("video");
  const source = preview.querySelector("source");
  const caption = panel.querySelector("[data-caption]");
  const input = panel.querySelector("[data-input]");
  observer.observe(preview);

  buttons.forEach((button, index) => {
    button.addEventListener("click", () => {
      if (button.getAttribute("aria-pressed") === "true") return;
      const selection = entries[index];
      const base = `media/${selection.key}`;
      const wasPlaying = !preview.paused;
      for (const option of buttons) {
        option.setAttribute("aria-pressed", String(option === button));
      }
      preview.poster = `${base}.webp`;
      preview.setAttribute("aria-label", selection.label);
      source.src = `${base}.mp4`;
      caption.textContent = selection.caption;
      if (input) {
        input.src = `${base}-input.webp`;
        panel.querySelector("[data-prompt]").textContent = selection.prompt;
        panel.querySelector("[data-negative]").textContent = selection.negative;
        panel.querySelector("[data-reference-image]").src = `${base}-reference.webp`;
        panel.querySelector("[data-reference]").textContent = selection.reference;
      }
      preview.load();
      if (wasPlaying) preview.play().catch(() => {});
    });
  });
}
